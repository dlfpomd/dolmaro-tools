"""2단: 로컬 웹 (FastAPI + 정적 HTML 1장).

drag/drop 업로드 → SSE stepper(무음 → 자막 → 잔말/NG → 드래프트) → 결과 카드.
파이프라인 본체는 pipeline.run(공유). 여기서는 업로드/SSE 만 담당한다.

런타임 함정:
  · ASR 전사는 asr 모듈의 스레드 락으로 직렬화(numba 비스레드세이프).
  · 파이프라인은 to_thread 로 실행해 이벤트루프 비차단, 진행은 큐로 스트림.
  · 단계당 최소 0.5s 지연(step_delay) → 캐시 hit 시에도 애니메이션 가시화.
"""

from __future__ import annotations

import asyncio
import json
import tempfile
import uuid
from pathlib import Path

from fastapi import FastAPI, Form, UploadFile
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse

from . import config
from .pipeline import Options, PipelineError, run

STATIC = Path(__file__).parent / "static"
UPLOAD_DIR = Path(tempfile.gettempdir()) / "capcut_agent_uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
STEP_MIN_DELAY = 0.5

app = FastAPI(title="캡컷 에이전트")
JOBS: dict[str, dict] = {}


def _sse(event: str, data: dict) -> str:
    return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"


@app.get("/")
async def index() -> FileResponse:
    return FileResponse(STATIC / "index.html")


@app.post("/api/upload")
async def upload(
    file: UploadFile,
    min_silence: float = Form(config.DEFAULT_MIN_SILENCE),
    noise: float = Form(config.DEFAULT_NOISE_DB),
    draft_name: str = Form(""),
) -> JSONResponse:
    """무음 컷 전용 — 영상 + 무음 파라미터만 받는다."""
    job_id = uuid.uuid4().hex[:12]
    suffix = Path(file.filename or "video.mp4").suffix or ".mp4"
    dest = UPLOAD_DIR / f"{job_id}{suffix}"
    with open(dest, "wb") as f:
        while chunk := await file.read(1 << 20):
            f.write(chunk)

    stem = Path(file.filename or "video").stem
    JOBS[job_id] = {
        "path": str(dest),
        "opts": Options(
            min_silence=min_silence, noise=noise,
            draft_name=draft_name.strip() or f"{stem}_agent",
            draft_folder=str(config.default_draft_folder()),
            # 자막/잔말/NG 는 비활성(무음 컷 전용 앱).
        ),
    }
    return JSONResponse({"job_id": job_id, "filename": file.filename})


@app.get("/api/process/{job_id}")
async def process(job_id: str) -> StreamingResponse:
    job = JOBS.get(job_id)

    async def gen():
        if job is None:
            yield _sse("error", {"message": "알 수 없는 job_id"})
            return

        loop = asyncio.get_running_loop()
        queue: asyncio.Queue = asyncio.Queue()

        def on_step(sid, status, detail):
            loop.call_soon_threadsafe(
                queue.put_nowait,
                ("step", {"id": sid, "status": status, "detail": detail}))

        def worker():
            try:
                result = run(job["path"], job["opts"], on_step, step_delay=STEP_MIN_DELAY)
                loop.call_soon_threadsafe(queue.put_nowait, ("done", result))
            except PipelineError as e:
                loop.call_soon_threadsafe(queue.put_nowait, ("error", {"message": str(e)}))
            except Exception as e:  # 예기치 못한 실패
                loop.call_soon_threadsafe(
                    queue.put_nowait, ("error", {"message": f"{type(e).__name__}: {e}"}))
            finally:
                loop.call_soon_threadsafe(queue.put_nowait, None)

        task = asyncio.create_task(asyncio.to_thread(worker))
        try:
            while True:
                item = await queue.get()
                if item is None:
                    break
                event, data = item
                yield _sse(event, data)
        finally:
            await task

    return StreamingResponse(
        gen(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


def main():
    import uvicorn
    print("● 캡컷 에이전트 웹 → http://127.0.0.1:8000")
    uvicorn.run(app, host="127.0.0.1", port=8000, log_level="warning")


if __name__ == "__main__":
    main()

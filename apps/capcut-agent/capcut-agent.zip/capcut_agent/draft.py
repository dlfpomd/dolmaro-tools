"""보존 구간 목록 → CapCut 점프컷 드래프트 생성.

pycapcut 함정 메모:
- 시간 단위는 마이크로초. `tim(float)` 는 초가 아니라 마이크로초로 해석되므로
  반드시 `int(round(sec * SEC))` 로 직접 변환한다.
- source_timerange = 원본에서 잘라올 구간, target_timerange = 타임라인 배치 구간.
  무음 제거 = 보존 구간을 타임라인에 연속(빈틈 없이) 이어 붙이는 것.
"""

from __future__ import annotations

from pathlib import Path

import pycapcut as pc

from .silence import Segment

SEC = pc.SEC  # 1_000_000


def _us(seconds: float) -> int:
    """초 → 마이크로초 (반올림 정수)."""
    return int(round(seconds * SEC))


def build_jumpcut_draft(
    video_path: str,
    keeps: list[Segment],
    draft_name: str,
    draft_folder: str | Path,
    fps: int = 30,
    material_holder: dict | None = None,
) -> tuple[str, float]:
    """보존 구간만 이어 붙인 점프컷 드래프트를 생성·저장한다.

    material_holder: 주어지면 {"script", "material"} 을 담아 호출자에게 넘긴다
        (이후 같은 드래프트에 자막 트랙을 추가할 때 재사용).
    반환: (드래프트 경로, 최종 타임라인 길이[초]).
    """
    if not keeps:
        raise ValueError("보존 구간이 비어 있습니다. 무음 임계값을 확인하세요.")

    folder = Path(draft_folder)
    folder.mkdir(parents=True, exist_ok=True)

    material = pc.VideoMaterial(str(video_path))
    draft_folder_obj = pc.DraftFolder(str(folder))
    script = draft_folder_obj.create_draft(
        draft_name, material.width, material.height, fps, allow_replace=True
    )
    script.add_track(pc.TrackType.video)

    # ffprobe 길이와 pycapcut 소재 길이가 µs 단위로 어긋날 수 있다
    # (예: ffprobe 26.400998s vs material 26.400000s). 소스 끝을 소재 길이로
    # 클램프해 "범위 초과" 오류를 막는다.
    mat_dur_us = material.duration
    timeline_us = 0
    for k in keeps:
        src_start_us = _us(k.start)
        src_end_us = min(_us(k.end), mat_dur_us)
        dur_us = src_end_us - src_start_us
        if dur_us <= 0:
            continue
        seg = pc.VideoSegment(
            material,
            target_timerange=pc.Timerange(timeline_us, dur_us),
            source_timerange=pc.Timerange(src_start_us, dur_us),
        )
        script.add_segment(seg)
        timeline_us += dur_us

    script.save()
    if material_holder is not None:
        material_holder["script"] = script
        material_holder["material"] = material
    draft_path = folder / draft_name
    return str(draft_path), timeline_us / SEC

"""4단: 잔말(filler) + NG(반복 테이크) 감지 → 컷 구간 산출.

원칙(원본 프롬프트): 전체 대본(transcript) 기준으로 판단. 단어 단위 휴리스틱이
아니라 '대본 위의 토큰 시퀀스'로 본다.
  · 잔말: 단독으로 나온 한국어 간투사(기본 세트)를 투명하게 제거.
  · NG: 같은 토큰 시퀀스가 연속으로 반복되면 앞 테이크를 잘라 마지막 테이크만 남김.
산출은 (start, end) 컷 구간 리스트(초). silence 보존 구간에서 빼내어 쓴다.
"""

from __future__ import annotations

import re
from difflib import SequenceMatcher

from .asr import Word
from .silence import Segment

# 기본 잔말 세트: 단독 토큰으로 나올 때만 컷(부분 문자열 매치 안 함).
# 보수적 코어 — "좀/약간/이/그게" 등 의미 충돌이 큰 건 일부러 제외(오컷 방지).
DEFAULT_FILLERS = {
    "어", "음", "그", "이제", "인제", "뭐", "막", "에",
    "쩝", "크흠", "쓰읍", "흡",   # 명백한 입소리
}

_PUNCT = re.compile(r"[^\w가-힣%]")


def _norm(token: str) -> str:
    """토큰 정규화: 공백/문장부호 제거."""
    return _PUNCT.sub("", token.strip())


def detect_filler_spans(words: list[Word], fillers: set[str] | None = None) -> list[tuple[float, float]]:
    """단독 잔말 토큰의 (start, end) 구간 목록. 인접 잔말은 병합."""
    fillers = DEFAULT_FILLERS if fillers is None else fillers
    spans: list[tuple[float, float]] = []
    for w in words:
        if _norm(w.text) in fillers:
            if spans and w.start - spans[-1][1] < 0.12:
                spans[-1] = (spans[-1][0], w.end)  # 인접 잔말 병합
            else:
                spans.append((w.start, w.end))
    return spans


def _tok_sim(a: str, b: str) -> float:
    """토큰 유사도 0~1 (조사 차이=접두 일치, 발음 흔들림=문자 비율 흡수)."""
    if a == b:
        return 1.0
    if not a or not b:
        return 0.0
    if a.startswith(b) or b.startswith(a):
        return min(len(a), len(b)) / max(len(a), len(b))
    return SequenceMatcher(None, a, b).ratio()


def detect_ng_spans(
    words: list[Word],
    min_run: int = 1,
    max_run: int = 20,
    max_gap_tokens: int = 4,
    sim_th: float = 0.65,
) -> list[tuple[float, float]]:
    """연속 반복(재촬영/더듬음) 구간의 앞 테이크를 컷 구간으로 반환.

    토큰 시퀀스가 곧이어 다시 나오면 첫 등장 [start_i, start_j) 를 컷(뒤 테이크
    보존). 음성인식이 같은 말을 조금씩 다르게 받아써도 잡도록 퍼지(유사도)로 비교.
      · 2어절 이상: 중간 max_gap_tokens 이내 반복까지 허용
      · 1어절(예: '아자티오프린 아자티오프린'): 바로 붙은 경우만, 3글자 이상 단어만
        (떨어져 있으면 같은 용어의 정상 재언급일 수 있어 제외)
    최장 반복 우선, 그리디.
    """
    toks = [_norm(w.text) for w in words]
    n = len(toks)
    spans: list[tuple[float, float]] = []

    def run_matches(i: int, j: int, L: int) -> bool:
        strong = 0
        for k in range(L):
            a, b = toks[i + k], toks[j + k]
            if not a or _tok_sim(a, b) < sim_th:
                return False
            if len(a) >= 2:
                strong += 1
        if L == 1:
            # 단일 어절 반복: 충분히 긴 단어만(짧은 '네/자/이' 등 오컷 방지)
            return len(toks[i]) >= 3
        return strong >= max(2, L // 2)

    i = 0
    while i < n:
        found = None  # (L, j)
        max_L = min(max_run, (n - i) // 2)
        for L in range(max_L, max(min_run, 1) - 1, -1):   # 최장부터
            gaps = (0,) if L == 1 else range(0, max_gap_tokens + 1)
            for g in gaps:
                j = i + L + g
                if j + L > n:
                    continue
                if run_matches(i, j, L):
                    found = (L, j)
                    break
            if found:
                break
        if found:
            L, j = found
            spans.append((words[i].start, words[j].start))
            i = j  # 둘째 테이크부터 계속
        else:
            i += 1
    return spans


def merge_spans(spans: list[tuple[float, float]]) -> list[tuple[float, float]]:
    if not spans:
        return []
    spans = sorted(spans)
    out = [spans[0]]
    for s, e in spans[1:]:
        if s <= out[-1][1]:
            out[-1] = (out[-1][0], max(out[-1][1], e))
        else:
            out.append((s, e))
    return out


def subtract_spans(
    keeps: list[Segment],
    cut_spans: list[tuple[float, float]],
    min_keep: float = 0.10,
) -> list[Segment]:
    """보존 구간에서 컷 구간을 빼낸다. 분할 결과 중 너무 짧은 건 버린다."""
    cuts = merge_spans(cut_spans)
    out: list[Segment] = []
    for k in keeps:
        pieces = [(k.start, k.end)]
        for cs, ce in cuts:
            nxt = []
            for s, e in pieces:
                if ce <= s or cs >= e:
                    nxt.append((s, e))
                    continue
                if cs > s:
                    nxt.append((s, min(cs, e)))
                if ce < e:
                    nxt.append((max(ce, s), e))
            pieces = nxt
        for s, e in pieces:
            if e - s >= min_keep:
                out.append(Segment(s, e))
    return out


def find_review_points(words: list[Word], long_word_th: float = 1.8) -> list[tuple[float, float, str]]:
    """수동 점검 지점 — 비정상적으로 긴 단어(반복/더듬음/입소리가 흡수된 곳).

    음성인식은 즉시 반복("아자티오프린 아자티오프린")이나 입소리를 한 단어로
    합쳐 해당 단어의 길이가 비정상적으로 길어진다. 자동 컷은 어렵지만, 그 위치를
    짚어 사용자가 직접 다듬게 한다. 반환: (start, end, 설명).
    """
    pts: list[tuple[float, float, str]] = []
    for w in words:
        dur = w.end - w.start
        if dur >= long_word_th:
            pts.append((w.start, w.end, f"'{w.text.strip()}' 가 {dur:.1f}초 — 반복/더듬음/입소리 의심"))
    return pts

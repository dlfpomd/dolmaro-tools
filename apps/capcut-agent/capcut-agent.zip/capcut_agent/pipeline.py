"""공유 파이프라인: silence → asr → filler/NG → draft(+자막).

CLI(cli.py)와 웹 서버(server.py)가 동일 로직을 쓰도록 한곳에 모은다.
on_step(id, status, detail) 콜백으로 진행을 보고한다. 단계 id 는
silence | asr | filler | draft, status 는 run | done | skip | error.

graceful: ASR 실패 시 자막·잔말·NG 는 건너뛰고 점프컷 드래프트는 계속 만든다.
"""

from __future__ import annotations

import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from . import config
from .draft import build_jumpcut_draft
from .filler import detect_filler_spans, detect_ng_spans, subtract_spans
from .silence import Segment, analyze, probe_duration

StepCb = Callable[[str, str, str], None]


class PipelineError(Exception):
    pass


@dataclass
class Options:
    no_cut: bool = False
    subtitles: bool = False
    remove_filler: bool = False
    remove_ng: bool = False
    sub_model: str = "large-v3"
    noise: float = config.DEFAULT_NOISE_DB
    min_silence: float = config.DEFAULT_MIN_SILENCE
    pad: float = config.DEFAULT_PAD
    min_keep: float = config.DEFAULT_MIN_KEEP
    fps: int = 30
    draft_name: str = "agent"
    draft_folder: str = ""
    filler_words: Optional[set] = None
    script_text: str = ""        # 원본 대본(선택)
    strict_script_cut: bool = False  # 대본 '엄격 컷'(대본대로 읽은 영상에서만 권장)


def _needs_asr(o: Options) -> bool:
    return (o.subtitles or o.remove_filler or o.remove_ng
            or (o.strict_script_cut and bool(o.script_text.strip())))


class _Stepper:
    """콜백 + 단계당 최소 지연(애니메이션 가시화) 처리."""

    def __init__(self, cb: Optional[StepCb], min_delay: float):
        self.cb = cb or (lambda *_: None)
        self.min_delay = min_delay
        self.t0 = None

    def start(self, sid: str):
        self.t0 = time.monotonic()
        self.cb(sid, "run", "")

    def end(self, sid: str, detail: str = "", status: str = "done"):
        if self.min_delay and self.t0 is not None:
            rem = self.min_delay - (time.monotonic() - self.t0)
            if rem > 0:
                time.sleep(rem)
        self.cb(sid, status, detail)
        self.t0 = None

    def skip(self, sid: str, detail: str = "건너뜀"):
        self.cb(sid, "skip", detail)


def run(video_path: str, opts: Options, on_step: Optional[StepCb] = None,
        step_delay: float = 0.0) -> dict:
    step = _Stepper(on_step, step_delay)
    folder = opts.draft_folder or str(config.default_draft_folder())
    result: dict = {"draft_folder": folder}

    # ── 1) 무음 → 보존 구간 ───────────────────────────────────────────
    step.start("silence")
    if opts.no_cut:
        duration = probe_duration(video_path)
        keeps, silences = [Segment(0.0, duration)], []
    else:
        keeps, silences, duration = analyze(
            video_path, opts.noise, opts.min_silence, opts.pad, opts.min_keep)
    result.update(duration=duration, silences=len(silences))
    if not keeps:
        step.end("silence", "보존 구간 없음", status="error")
        raise PipelineError("보존 구간이 없습니다 — 무음 임계값을 조정하세요.")
    step.end("silence", f"{len(silences)}개 무음")

    # ── 2) ASR (자막/잔말/NG 중 하나라도 필요할 때) ──────────────────
    transcript = None
    if _needs_asr(opts):
        step.start("asr")
        print(f"  · 음성인식 중 (모델 {opts.sub_model}, 영상 {result['duration']:.0f}초)... "
              f"CPU에서는 영상 길이의 몇 배가 걸릴 수 있습니다.", flush=True)
        try:
            from .asr import transcribe
            transcript = transcribe(video_path, model_size=opts.sub_model)
            result["script"] = transcript.script
            # 검증/디버그용: 음성인식 전사를 바탕화면에 저장(단어 타임스탬프 포함).
            try:
                import json as _json
                desktop = Path.home() / "Desktop"
                tpath = (desktop if desktop.is_dir() else Path.home()) / f"{opts.draft_name}_전사.json"
                tpath.write_text(_json.dumps(transcript.to_dict(), ensure_ascii=False),
                                 encoding="utf-8")
                result["transcript_path"] = str(tpath)
            except Exception:
                pass
            step.end("asr", f"{len(transcript.segments)}세그먼트")
        except Exception as e:  # 모델 미존재/네트워크 → graceful 강등
            transcript = None
            result["asr_error"] = f"{type(e).__name__}: {e}"
            step.end("asr", result["asr_error"], status="error")
    else:
        step.skip("asr")

    # ── 3) 잔말 + NG (transcript 필요) ───────────────────────────────
    strict = opts.strict_script_cut and bool(opts.script_text.strip())
    if transcript is not None and (opts.remove_filler or opts.remove_ng or strict):
        step.start("filler")
        cut_spans: list[tuple[float, float]] = []
        parts: list[str] = []
        if opts.remove_filler:
            fs = detect_filler_spans(transcript.words, opts.filler_words)
            cut_spans += fs
            parts.append(f"잔말 {len(fs)}")
        # 보수적 반복 감지 — 전사에 잡힌 재촬영/더듬음 반복만 컷(오컷 없음).
        if opts.remove_ng:
            ng = detect_ng_spans(transcript.words)
            cut_spans += ng
            parts.append(f"반복 {len(ng)}")
        # 대본 '엄격 컷'(opt-in): 대본대로 정확히 읽은 영상에서만. 애드립이 많으면
        # 정상 발화를 과도하게 자르므로 기본 비활성.
        if strict:
            from .script_align import align_cut_spans
            spans, info = align_cut_spans(transcript.words, opts.script_text)
            frac = info.get("matched_frac", 0.0)
            result["script_match_frac"] = frac
            if info.get("unreliable"):
                parts.append(f"대본정렬 생략(일치 {frac * 100:.0f}%↓)")
            else:
                cut_spans += spans
                parts.append(f"대본정렬 {len(spans)}(일치 {frac * 100:.0f}%)")
        before = sum(k.end - k.start for k in keeps)
        keeps = subtract_spans(keeps, cut_spans, opts.min_keep)
        after = sum(k.end - k.start for k in keeps)
        result["filler_spans"] = len(cut_spans)
        result["filler_removed"] = before - after
        if not keeps:
            step.end("filler", "모든 구간이 컷됨", status="error")
            raise PipelineError("잔말/NG 컷으로 보존 구간이 모두 사라졌습니다. "
                                "대본이 영상과 맞는지 확인하세요.")
        step.end("filler", f"{' · '.join(parts)} · {before - after:.1f}s 제거")
    else:
        step.skip("filler", "건너뜀" if transcript is not None else "ASR 없음")

    # ── 4) 드래프트 + 자막 ───────────────────────────────────────────
    step.start("draft")
    print(f"  · 드래프트 생성 중 (보존 {len(keeps)}구간)...", flush=True)
    holder: dict = {}
    draft_path, final_len = build_jumpcut_draft(
        video_path, keeps, opts.draft_name, folder, opts.fps, holder)
    print("  · 드래프트 파일 저장 완료", flush=True)
    # CapCut 마스터 색인(root_meta_info)에 등록 → 목록에 안정적으로 표시.
    try:
        from .capcut_register import register_draft
        vsize = os.path.getsize(video_path) if os.path.exists(video_path) else 0
        msg = register_draft(folder, opts.draft_name, final_len, materials_size=vsize)
        result["registered"] = msg
        print(f"  · CapCut 목록 등록: {msg}", flush=True)
    except Exception as e:
        print(f"  · CapCut 목록 등록 생략(드래프트는 정상): {e}", flush=True)
    if transcript is not None and opts.subtitles:
        from .subtitle import chunk_words, remap_words_to_cut, write_srt
        print(f"  · 자막 SRT 생성 중 (단어 {len(transcript.words)}개)...", flush=True)
        # 잘린 단어(잔말/NG/무음)를 먼저 제거+재매핑한 뒤 청킹 → 자막이 컷 영상과 일치.
        kept_words = remap_words_to_cut(transcript.words, keeps)
        cues = chunk_words(
            kept_words,
            max_chars=config.DEFAULT_MAX_LINE_CHARS,
            hard_max=config.DEFAULT_HARD_MAX_CHARS,
            pause_break=config.DEFAULT_PAUSE_BREAK,
        )
        srt_path = str(Path(draft_path) / "subtitles.srt")
        write_srt(cues, srt_path)
        # 자막을 드래프트에 임베드하지 않는다 — 일부 CapCut 버전이 임베드 텍스트
        # 트랙 때문에 드래프트 전체를 목록에서 거부한다(자막도 안 보임). 대신 SRT
        # 파일로 제공하고 사용자가 CapCut 에서 직접 가져온다(어느 버전이든 동작).
        try:
            desktop = Path.home() / "Desktop"
            easy = (desktop if desktop.is_dir() else Path.home()) / f"{opts.draft_name}_자막.srt"
            write_srt(cues, str(easy))
            result["srt_easy"] = str(easy)
        except Exception:
            result["srt_easy"] = srt_path
        result["cue_count"] = len(cues)
        result["subtitles_added"] = True
        print(f"  · 자막 {len(cues)}줄 SRT 저장 완료 (CapCut에서 가져오기)", flush=True)

    # 수동 점검 지점: 자동 컷이 어려운 더듬음/반복(긴 단어에 흡수)을 컷 타임라인
    # 시각으로 짚어 바탕화면에 저장 → 사용자가 CapCut 에서 그 지점만 직접 다듬음.
    if transcript is not None:
        try:
            from .filler import find_review_points
            from .subtitle import map_time_to_cut
            lines = []
            for s, _e, label in find_review_points(transcript.words):
                ns = map_time_to_cut(s, keeps)
                if ns is None:
                    continue
                mm, ss = divmod(int(ns), 60)
                lines.append(f"[{mm:02d}:{ss:02d}] {label}")
            if lines:
                desktop = Path.home() / "Desktop"
                rpath = (desktop if desktop.is_dir() else Path.home()) / f"{opts.draft_name}_점검지점.txt"
                rpath.write_text(
                    "CapCut에서 아래 시각으로 이동해 더듬음/반복/입소리를 직접 확인·삭제하세요.\n"
                    "(음성인식이 한 단어로 합쳐버려 자동 컷이 어려운 지점들입니다.)\n\n"
                    + "\n".join(lines), encoding="utf-8")
                result["review_path"] = str(rpath)
                result["review_count"] = len(lines)
                print(f"  · 수동 점검 지점 {len(lines)}곳 저장: {rpath}", flush=True)
        except Exception:
            pass
    kept = sum(k.end - k.start for k in keeps)
    result.update(draft_path=draft_path, final_len=final_len,
                  draft_name=opts.draft_name, cuts=len(keeps),
                  kept=kept, removed=result["duration"] - kept)
    step.end("draft", f"타임라인 {final_len:.1f}s")

    return result

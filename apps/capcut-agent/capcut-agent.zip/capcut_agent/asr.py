"""ASR (faster-whisper) 래퍼 — fallback/트랙C 공용.

함정 메모:
- whisper 내부 numba 는 스레드세이프하지 않다 → 모듈 락으로 전사 호출을 직렬화
  (동시 호출 시 segfault). FastAPI(2단)에서는 asyncio.Lock 으로 감싼다.
- 모델 로드는 비싸다 → 크기별로 캐시.
- 전사 결과는 content hash 로 캐시(파일 mtime 은 매 업로드 miss).
- 이 컨테이너(클라우드)는 huggingface.co 차단으로 모델 다운로드 불가 →
  실제 전사는 사용자 로컬(Mac/Win)에서 수행. 코드는 faster-whisper 1.2.x 기준.
"""

from __future__ import annotations

import hashlib
import json
import threading
from dataclasses import asdict, dataclass, field
from pathlib import Path

# numba 비스레드세이프 → 전사 직렬화 락
_ASR_LOCK = threading.Lock()
_MODEL_CACHE: dict[tuple, object] = {}


@dataclass
class Word:
    start: float
    end: float
    text: str


@dataclass
class Seg:
    start: float
    end: float
    text: str
    words: list[Word] = field(default_factory=list)


@dataclass
class Transcript:
    language: str
    duration: float
    segments: list[Seg]

    @property
    def script(self) -> str:
        """전체 대본(붙여 쓴 한 덩어리). NG/자막 판단의 기준."""
        return " ".join(s.text.strip() for s in self.segments).strip()

    @property
    def words(self) -> list[Word]:
        out: list[Word] = []
        for s in self.segments:
            out.extend(s.words)
        return out

    def to_dict(self) -> dict:
        return {
            "language": self.language,
            "duration": self.duration,
            "segments": [
                {"start": s.start, "end": s.end, "text": s.text,
                 "words": [asdict(w) for w in s.words]}
                for s in self.segments
            ],
        }

    @classmethod
    def from_dict(cls, d: dict) -> "Transcript":
        segs = [
            Seg(s["start"], s["end"], s["text"],
                [Word(**w) for w in s.get("words", [])])
            for s in d["segments"]
        ]
        return cls(d["language"], d["duration"], segs)


def content_hash(path: str, chunk_mb: int = 8) -> str:
    """파일 앞부분 + 크기로 빠른 content hash (업로드마다 안정)."""
    h = hashlib.sha256()
    p = Path(path)
    h.update(str(p.stat().st_size).encode())
    with open(path, "rb") as f:
        h.update(f.read(chunk_mb * 1024 * 1024))
    return h.hexdigest()[:16]


def _get_model(model_size: str, device: str, compute_type: str):
    key = (model_size, device, compute_type)
    if key not in _MODEL_CACHE:
        from faster_whisper import WhisperModel  # 지연 import (무거움)
        _MODEL_CACHE[key] = WhisperModel(
            model_size, device=device, compute_type=compute_type
        )
    return _MODEL_CACHE[key]


def transcribe(
    audio_path: str,
    model_size: str = "large-v3",
    language: str = "ko",
    device: str = "cpu",
    compute_type: str = "int8",
    cache_dir: str | Path | None = None,
    vad_filter: bool = True,
) -> Transcript:
    """오디오/영상 → Transcript(세그먼트 + 단어 타임스탬프).

    content hash 기반 캐시. 전사는 _ASR_LOCK 으로 직렬화.
    Mac Intel CPU 기준 model_size 권장: 품질 large-v3, 속도 medium.
    """
    cache_dir = Path(cache_dir) if cache_dir else Path(audio_path).parent / ".asr_cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    chash = content_hash(audio_path)
    # 끝의 v2: 전사 설정(condition_on_previous_text 등)이 바뀌면 캐시 무효화.
    cache_file = cache_dir / f"{chash}_{model_size}_{language}_v2.json"
    if cache_file.exists():
        return Transcript.from_dict(json.loads(cache_file.read_text(encoding="utf-8")))

    with _ASR_LOCK:
        model = _get_model(model_size, device, compute_type)
        segments, info = model.transcribe(
            audio_path, language=language, word_timestamps=True, vad_filter=vad_filter,
            # 더듬음/반복을 '정리'하지 않고 그대로 받아쓰게 한다(NG 감지에 필요).
            condition_on_previous_text=False,
            # 끝부분/낮은 볼륨 발화를 덜 버리도록 임계 완화.
            no_speech_threshold=0.6,
        )
        segs: list[Seg] = []
        for s in segments:  # 제너레이터 — 여기서 실제 디코딩 발생
            words = [Word(w.start, w.end, w.word) for w in (s.words or [])]
            segs.append(Seg(s.start, s.end, s.text.strip(), words))

    tr = Transcript(info.language, float(info.duration), segs)
    cache_file.write_text(
        json.dumps(tr.to_dict(), ensure_ascii=False), encoding="utf-8"
    )
    return tr

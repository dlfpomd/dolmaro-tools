"""CLI: 무음 컷 + (선택) 자막/잔말/NG → CapCut 드래프트.

사용:
    python -m capcut_agent.cli input.mp4
    python -m capcut_agent.cli input.mp4 --subtitles --filler --ng
    python -m capcut_agent.cli input.mp4 --no-cut --subtitles --sub-model medium
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import config
from .pipeline import Options, PipelineError, run


def _on_step(sid: str, status: str, detail: str) -> None:
    mark = {"run": "…", "done": "✓", "skip": "·", "error": "✗"}.get(status, " ")
    label = {"silence": "무음", "asr": "자막(ASR)", "filler": "잔말·NG", "draft": "드래프트"}[sid]
    if status == "run":
        return  # 시작은 조용히, 결과만 출력
    print(f"  {mark} {label}: {detail}")


def main(argv: list[str] | None = None) -> int:
    track = config.detect_track()
    settings = config.EditSettings()

    p = argparse.ArgumentParser(description="캡컷 에이전트 — 무음/자막/잔말/NG 자동 컷")
    p.add_argument("video", help="입력 mp4/mov 경로")
    p.add_argument("--name", default=None, help="드래프트 이름 (기본: 파일명 기반)")
    p.add_argument("--draft-folder", default=str(settings.draft_folder))
    p.add_argument("--noise", type=float, default=settings.noise_db, help="노이즈 게이트(dB)")
    p.add_argument("--min-silence", type=float, default=settings.min_silence,
                   help="컷 대상 최소 무음 길이(초)")
    p.add_argument("--pad", type=float, default=settings.pad, help="컷 경계 여유(초)")
    p.add_argument("--min-keep", type=float, default=settings.min_keep)
    p.add_argument("--fps", type=int, default=settings.fps)
    p.add_argument("--no-cut", action="store_true", help="무음 컷 없이 전체 유지")
    p.add_argument("--subtitles", action="store_true", help="ASR 자막 생성+추가")
    p.add_argument("--filler", action="store_true", help="잔말(어/음/그…) 컷 (ASR 필요)")
    p.add_argument("--ng", action="store_true", help="NG 반복 테이크 컷 (ASR 필요)")
    p.add_argument("--script", default=None,
                   help="원본 대본 txt 경로. 주면 대본 정렬로 더듬음/NG 정밀 교정")
    p.add_argument("--sub-model", default="large-v3",
                   help="whisper 모델. Mac Intel CPU: 품질 large-v3 / 속도 medium")
    args = p.parse_args(argv)

    video = Path(args.video)
    if not video.exists():
        print(f"✗ 입력 영상을 찾을 수 없습니다: {video}", file=sys.stderr)
        return 1

    script_text = ""
    if args.script:
        sp = Path(args.script)
        if not sp.exists():
            print(f"✗ 대본 파일을 찾을 수 없습니다: {sp}", file=sys.stderr)
            return 1
        script_text = sp.read_text(encoding="utf-8")

    opts = Options(
        no_cut=args.no_cut,
        subtitles=args.subtitles,
        remove_filler=args.filler,
        remove_ng=args.ng,
        sub_model=args.sub_model,
        noise=args.noise,
        min_silence=args.min_silence,
        pad=args.pad,
        min_keep=args.min_keep,
        fps=args.fps,
        draft_name=args.name or f"{video.stem}_agent",
        draft_folder=args.draft_folder,
        script_text=script_text,
    )

    print(f"● 트랙 {track.name} · {track.label} · ASR={track.asr_backend}")
    print(f"● 분석: {video.name}")
    try:
        result = run(str(video), opts, on_step=_on_step)
    except PipelineError as e:
        print(f"✗ {e}", file=sys.stderr)
        return 2

    print(f"✓ 드래프트 저장: {result['draft_path']}")
    print(f"  원본 {result['duration']:.2f}s · 제거 {result['removed']:.2f}s "
          f"· 결과 {result['final_len']:.2f}s · {result['cuts']}컷"
          + (f" · 자막 {result['cue_count']}줄" if result.get("subtitles_added") else ""))
    print("  CapCut 에서 열어 직접 재생 검증하세요. (빌드 성공 ≠ 검증)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

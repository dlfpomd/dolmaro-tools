"""무음 구간 감지 + 보존(말소리) 구간 계산.

ffmpeg 의 silencedetect 필터로 무음 구간을 찾고, 그 여집합을 보존 구간으로
환산한다. 점프컷의 핵심 1단.
"""

from __future__ import annotations

import re
import subprocess
from dataclasses import dataclass


@dataclass
class Segment:
    """초 단위 [start, end) 구간."""

    start: float
    end: float

    @property
    def duration(self) -> float:
        return self.end - self.start


_SILENCE_START = re.compile(r"silence_start:\s*(-?[\d.]+)")
_SILENCE_END = re.compile(r"silence_end:\s*(-?[\d.]+)")
_DURATION = re.compile(r"Duration:\s*(\d+):(\d+):(\d+\.?\d*)")


def ffmpeg_exe() -> str:
    """ffmpeg 실행 파일 경로. pip 로 번들된 imageio-ffmpeg 우선(윈도우에서 수동
    설치 불필요), 없으면 PATH 의 'ffmpeg'."""
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return "ffmpeg"


def _parse_duration(log: str) -> float | None:
    m = _DURATION.search(log)
    if not m:
        return None
    h, mn, s = int(m.group(1)), int(m.group(2)), float(m.group(3))
    return h * 3600 + mn * 60 + s


def probe_duration(path: str) -> float:
    """영상 총 길이(초). ffprobe 없이 ffmpeg 의 'Duration:' 출력에서 파싱
    (윈도우 번들 ffmpeg 에는 ffprobe 가 없으므로)."""
    proc = subprocess.run(
        [ffmpeg_exe(), "-hide_banner", "-i", path],
        capture_output=True, text=True,
    )
    dur = _parse_duration(proc.stderr)
    if dur is None:
        raise RuntimeError(f"영상 길이를 읽지 못했습니다: {path}")
    return dur


def detect_silences(
    path: str,
    noise_db: float = -30.0,
    min_silence: float = 0.4,
    duration: float | None = None,
) -> list[Segment]:
    """무음 구간 목록을 [0, duration] 범위로 정규화해 반환한다."""
    proc = subprocess.run(
        [
            ffmpeg_exe(), "-hide_banner", "-nostats", "-i", path,
            "-af", f"silencedetect=noise={noise_db}dB:d={min_silence}",
            "-f", "null", "-",
        ],
        capture_output=True, text=True,
    )
    log = proc.stderr
    if duration is None:
        # 같은 실행의 'Duration:' 출력에서 길이를 얻는다(별도 probe 불필요).
        duration = _parse_duration(log) or 0.0

    silences: list[Segment] = []
    pending_start: float | None = None
    for line in log.splitlines():
        if (m := _SILENCE_START.search(line)) is not None:
            pending_start = max(0.0, float(m.group(1)))
        elif (m := _SILENCE_END.search(line)) is not None:
            end = min(duration, float(m.group(1)))
            start = pending_start if pending_start is not None else 0.0
            if end > start:
                silences.append(Segment(start, end))
            pending_start = None
    # 파일이 무음으로 끝나면 silence_end 가 없을 수 있다 → duration 까지 닫는다.
    if pending_start is not None and duration > pending_start:
        silences.append(Segment(pending_start, duration))

    return silences


def compute_keeps(
    silences: list[Segment],
    duration: float,
    pad: float = 0.05,
    min_keep: float = 0.10,
) -> list[Segment]:
    """무음의 여집합 = 보존(말소리) 구간을 계산한다.

    pad: 무음을 안쪽으로 줄여 말 앞뒤 여유를 둔다(컷이 너무 바짝 붙지 않도록).
    min_keep: 이보다 짧은 조각은 버린다.
    """
    shrunk: list[Segment] = []
    for s in silences:
        ns, ne = s.start + pad, s.end - pad
        if ne > ns:
            shrunk.append(Segment(ns, ne))

    keeps: list[Segment] = []
    cursor = 0.0
    for s in sorted(shrunk, key=lambda x: x.start):
        if s.start > cursor:
            keeps.append(Segment(cursor, s.start))
        cursor = max(cursor, s.end)
    if cursor < duration:
        keeps.append(Segment(cursor, duration))

    return [k for k in keeps if k.duration >= min_keep]


def analyze(
    path: str,
    noise_db: float = -30.0,
    min_silence: float = 0.4,
    pad: float = 0.05,
    min_keep: float = 0.10,
) -> tuple[list[Segment], list[Segment], float]:
    """(보존 구간, 무음 구간, 총 길이) 를 한 번에 반환한다."""
    duration = probe_duration(path)
    silences = detect_silences(path, noise_db, min_silence, duration)
    keeps = compute_keeps(silences, duration, pad, min_keep)
    return keeps, silences, duration

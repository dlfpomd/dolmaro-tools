"""환경 감지 + CapCut 드래프트 폴더 경로 + 편집 기본값.

원본 프롬프트의 Step 0(OS 감지)을 런타임으로 구현한다.
트랙 A: Darwin/arm64 → mlx-whisper
트랙 C: Windows/AMD64 → faster-whisper (+ MP4 export)
fallback: Darwin/x86_64(Intel Mac) 및 그 외 → faster-whisper
"""

from __future__ import annotations

import os
import platform
from dataclasses import dataclass, field
from pathlib import Path


# ── 편집 기본값 (참고 쇼츠 실측으로 보정됨) ─────────────────────────────
# 보정 근거: 사용자가 직접 편집한 쇼츠(ACA/쇼그렌, 26s 클립 + 78s SRT) 실측.
#   · 최종본에 남긴 오디오 쉼: 0.31~0.43s (호흡/강조 쉼을 의도적으로 보존)
#   · 자막 간 간격: 평균 0.117s (대부분 0=연속)
#   · 한 줄 자막 글자수(공백 제외): 평균 14.9 / 최대 23
# 무음 판정: silencedetect 필터의 노이즈 게이트(dB)와 최소 무음 길이(초).
DEFAULT_NOISE_DB: float = -30.0
# 0.5s 이상만 컷 대상 → 사용자가 살려둔 0.43s 자연 쉼은 보존.
DEFAULT_MIN_SILENCE: float = 0.5
# 컷 경계 패딩(초). 컷된 무음은 양쪽 pad 만큼 남아 2*pad≈0.14s 간격이 된다
# (사용자 평균 쉼 0.117s 에 근접).
DEFAULT_PAD: float = 0.07
# 보존 구간 최소 길이: 이보다 짧은 조각(클릭음 등)은 버린다.
DEFAULT_MIN_KEEP: float = 0.10
# 한 줄 자막 소프트 타깃 글자수(공백 제외, 한글 기준). 실측 평균 15/최대 23.
# 쉼(pause)이 주 끊김 신호이고 길이는 안전 캡 → 소프트 18 / 하드 28.
DEFAULT_MAX_LINE_CHARS: int = 18
DEFAULT_HARD_MAX_CHARS: int = 28
# 자막 끊김용 단어 간 쉼 임계(초). 실측 평균 쉼 0.117s.
DEFAULT_PAUSE_BREAK: float = 0.12


@dataclass
class Track:
    """감지된 실행 트랙."""

    name: str           # "A" | "C" | "fallback"
    label: str
    asr_backend: str    # "mlx-whisper" | "faster-whisper"
    can_export_mp4: bool


def detect_track() -> Track:
    """현재 머신 기준 실행 트랙을 결정한다."""
    system = platform.system()
    machine = platform.machine().lower()

    if system == "Darwin" and machine in ("arm64", "aarch64"):
        return Track("A", "Mac (Apple Silicon)", "mlx-whisper", can_export_mp4=False)
    if system == "Windows" and machine in ("amd64", "x86_64"):
        return Track("C", "Windows (AMD64)", "faster-whisper", can_export_mp4=True)
    return Track(
        "fallback",
        f"{system} ({machine})",
        "faster-whisper",
        can_export_mp4=(system == "Windows"),
    )


def default_draft_folder() -> Path:
    """OS별 CapCut 드래프트 루트 폴더 경로를 추정한다.

    실제 존재 여부는 검사하지 않는다(클라우드/CI에서는 없을 수 있음).
    환경변수 CAPCUT_DRAFT_FOLDER 로 강제 지정 가능.
    """
    override = os.environ.get("CAPCUT_DRAFT_FOLDER")
    if override:
        return Path(override).expanduser()

    system = platform.system()
    home = Path.home()
    if system == "Darwin":
        return home / "Movies" / "CapCut" / "User Data" / "Projects" / "com.lveditor.draft"
    if system == "Windows":
        base = os.environ.get("LOCALAPPDATA", str(home / "AppData" / "Local"))
        return Path(base) / "CapCut" / "User Data" / "Projects" / "com.lveditor.draft"
    # Linux 등: 컨테이너 개발용 임시 경로
    return home / ".capcut_drafts"


@dataclass
class EditSettings:
    """무음/자막 편집 파라미터 묶음."""

    noise_db: float = DEFAULT_NOISE_DB
    min_silence: float = DEFAULT_MIN_SILENCE
    pad: float = DEFAULT_PAD
    min_keep: float = DEFAULT_MIN_KEEP
    max_line_chars: int = DEFAULT_MAX_LINE_CHARS
    fps: int = 30
    draft_folder: Path = field(default_factory=default_draft_folder)

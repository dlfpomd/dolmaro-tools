"""자막 청킹 + SRT 생성 + CapCut 드래프트 통합.

핵심 원칙(원본 프롬프트): 단어 단위 X → 전체 대본 기준의 '구(phrase) 단위' 자막.
사용자 샘플 SRT 실측으로 규칙 도출:
  · 의존명사(수/것/때/등…)로 줄을 시작하지 않는다 (실측 0건).
  · "수 있습니다" 류는 한 줄에 붙는다.
  · 줄은 호흡 쉼(단어 간 gap)·문장 종결·구 경계에서 끊는다.
  · 한 줄 공백제외 글자수 평균 15 / 최대 23 → 소프트 타깃 20, 하드 28.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

from .asr import Word

# 의존명사·일부 보조 어휘: 줄머리에 오면 안 됨(앞 어절에 붙인다).
BOUND_NOUNS = {
    "수", "것", "거", "줄", "바", "데", "때", "등", "뿐", "채", "지",
    "만큼", "듯", "양", "척", "체", "터", "리", "나름", "따름", "겸", "째",
}
_SENTENCE_END = tuple(".?!。！？")
_HANGUL = re.compile(r"[가-힣]")


@dataclass
class Cue:
    index: int
    start: float
    end: float
    text: str


def _nsp_len(words: list[Word]) -> int:
    """공백 제외 글자수."""
    return sum(len(w.text.strip()) for w in words)


def _first_token(text: str) -> str:
    return text.strip().split()[0] if text.strip() else ""


def _starts_with_bound(text: str) -> bool:
    tok = _first_token(text)
    # 앞쪽 비한글(따옴표 등) 제거 후 첫 어절이 의존명사인지
    return tok in BOUND_NOUNS


def _ends_sentence(text: str) -> bool:
    return text.strip().endswith(_SENTENCE_END)


def chunk_words(
    words: list[Word],
    max_chars: int = 18,
    hard_max: int = 28,
    pause_break: float = 0.12,
    min_chars: int = 5,
) -> list[Cue]:
    """단어 스트림 → 구 단위 자막 큐.

    끊기 판단(현재 단어 뒤에서):
      · 강제: 마지막 단어 / 문장 종결부호 / 하드 상한 초과
      · 자연: 다음 단어까지 쉼(gap) >= pause_break  또는  길이 >= max_chars
      · 단, 다음 줄이 의존명사로 시작하면 끊지 않는다(문장 종결/끝 제외).
    이후 너무 짧은 큐는 이웃과 병합.
    """
    cues: list[Cue] = []
    cur: list[Word] = []
    n = len(words)

    for i, w in enumerate(words):
        cur.append(w)
        last = i == n - 1
        length = _nsp_len(cur)
        gap = (words[i + 1].start - w.end) if not last else 1e9
        next_bound = (not last) and _starts_with_bound(words[i + 1].text)

        hard = length >= hard_max
        natural = (gap >= pause_break) or (length >= max_chars)
        sentence = _ends_sentence(w.text)

        # 의존명사 줄머리 금지: 문장 종결/마지막이 아니면 break 보류
        if last or sentence:
            do_break = True
        elif next_bound:
            do_break = False
        else:
            do_break = hard or natural

        if do_break:
            cues.append(_make_cue(cur, len(cues) + 1))
            cur = []

    if cur:
        cues.append(_make_cue(cur, len(cues) + 1))

    return _reindex(_merge_short(cues, words, min_chars))


def _make_cue(words: list[Word], index: int) -> Cue:
    text = " ".join(w.text.strip() for w in words).strip()
    text = re.sub(r"\s+", " ", text)
    return Cue(index, words[0].start, words[-1].end, text)


def _merge_short(cues: list[Cue], words: list[Word], min_chars: int) -> list[Cue]:
    """공백제외 글자수가 min_chars 미만인 큐를 인접 큐에 병합."""
    if len(cues) <= 1:
        return cues
    out: list[Cue] = []
    for c in cues:
        clen = len(c.text.replace(" ", ""))
        if clen < min_chars and out and not _starts_with_bound(c.text):
            prev = out[-1]
            out[-1] = Cue(prev.index, prev.start, c.end,
                          f"{prev.text} {c.text}".strip())
        elif clen < min_chars and out is not None and not out:
            # 첫 큐가 너무 짧으면 일단 유지(다음과 합쳐질 기회는 prev 로직에서)
            out.append(c)
        else:
            out.append(c)
    return out


def _reindex(cues: list[Cue]) -> list[Cue]:
    return [Cue(i + 1, c.start, c.end, c.text) for i, c in enumerate(cues)]


# ── SRT 입출력 ──────────────────────────────────────────────────────────

def _ts(seconds: float) -> str:
    if seconds < 0:
        seconds = 0.0
    ms = int(round(seconds * 1000))
    h, ms = divmod(ms, 3600_000)
    m, ms = divmod(ms, 60_000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def to_srt(cues: list[Cue]) -> str:
    blocks = []
    for c in cues:
        blocks.append(f"{c.index}\n{_ts(c.start)} --> {_ts(c.end)}\n{c.text}\n")
    return "\n".join(blocks)


def write_srt(cues: list[Cue], path: str) -> str:
    text = to_srt(cues)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    return path


def map_time_to_cut(original: float, keeps) -> float | None:
    """원본 시각 → 점프컷 타임라인 시각.

    keeps: 보존 구간 리스트(.start/.end, 초). 무음 제거 후 연속 배치 기준.
    원본 시각이 제거된(무음) 구간 안이면 None.
    """
    new_t = 0.0
    for k in keeps:
        if original >= k.end:
            new_t += k.end - k.start
        elif original >= k.start:
            return new_t + (original - k.start)
        else:
            return None  # 보존 구간들 사이(제거됨)
    return None


def remap_words_to_cut(words: list[Word], keeps) -> list[Word]:
    """단어 스트림을 점프컷 타임라인으로 옮기되, 컷된 구간의 단어는 제외한다.

    잔말/NG 컷으로 빠진 단어가 자막 텍스트에 남지 않도록 — '청킹 전에' 단어를
    거른다. 단어·보존구간이 모두 시간순이라 단일 패스(O(n+k))로 처리.
    """
    if not keeps:
        return []
    out: list[Word] = []
    ki = 0
    cum = 0.0           # 현재 keep 이전까지 보존된 누적 길이
    nk = len(keeps)
    for w in words:
        t = w.start
        while ki < nk and t >= keeps[ki].end:
            cum += keeps[ki].end - keeps[ki].start
            ki += 1
        if ki >= nk:
            break
        k = keeps[ki]
        if t < k.start:
            continue    # 제거된 구간의 단어 → 자막에서 제외
        ns = cum + (t - k.start)
        ne = cum + (min(w.end, k.end) - k.start)
        if ne <= ns:
            ne = ns + (w.end - t)
        out.append(Word(ns, ne, w.text))
    return out


def remap_cues_to_cut(cues: list[Cue], keeps) -> list[Cue]:
    """자막 큐 시각을 점프컷 타임라인으로 옮긴다.

    컷은 무음(말 없는 구간)에서 일어나므로 대부분 큐는 단순히 앞당겨진다.
    큐 양끝이 제거 구간에 걸리면 가장 가까운 보존 경계로 스냅. 완전히 제거된
    큐는 버린다.
    """
    out: list[Cue] = []
    total = sum(k.end - k.start for k in keeps)
    for c in cues:
        ns = map_time_to_cut(c.start, keeps)
        ne = map_time_to_cut(c.end, keeps)
        if ns is None:
            ns = _snap_forward(c.start, keeps)
        if ne is None:
            ne = _snap_backward(c.end, keeps)
        if ns is None or ne is None or ne <= ns:
            continue
        ns = max(0.0, min(ns, total))
        ne = max(0.0, min(ne, total))
        if ne > ns:
            out.append(Cue(len(out) + 1, ns, ne, c.text))
    return out


def _snap_forward(original: float, keeps) -> float | None:
    """제거 구간에 있는 시각을 '다음 보존 구간 시작'의 컷 시각으로."""
    new_t = 0.0
    for k in keeps:
        if original < k.start:
            return new_t
        if original <= k.end:
            return new_t + (original - k.start)
        new_t += k.end - k.start
    return None


def _snap_backward(original: float, keeps) -> float | None:
    """제거 구간에 있는 시각을 '이전 보존 구간 끝'의 컷 시각으로."""
    new_t = 0.0
    last = None
    for k in keeps:
        if original < k.start:
            return last
        if original <= k.end:
            return new_t + (original - k.start)
        new_t += k.end - k.start
        last = new_t
    return last


def add_subtitles_to_draft(script, srt_path: str, track_name: str = "자막"):
    """생성한 SRT 를 CapCut 드래프트 텍스트 트랙으로 가져온다."""
    script.import_srt(srt_path, track_name=track_name)
    return script

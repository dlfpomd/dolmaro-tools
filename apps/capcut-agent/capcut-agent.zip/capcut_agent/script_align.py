"""원본 대본(script) 기준 NG/더듬음 교정 — 전사↔대본 정렬.

원리: 사용자가 '의도한 대본'을 주면, ASR 전사를 대본에 강제 정렬(forced
alignment)한다. 대본과 맞물리지 않는 전사 단어(군말·더듬음·false start·재촬영
앞 테이크)는 컷 대상이 된다. 완전 일치 반복만 잡는 휴리스틱과 달리, '불완전
반복'("두가지 개념이 포함" → "두가지 개념이 포함되어 있습니다")과 발음 재시작
("인, 인후 이물" → "인두이물감")도 처리한다.

알고리즘: Needleman-Wunsch 류 DP.
  · diag = 대본 단어 R[i] 와 전사 단어 T[j] 정렬(유사도 기반, T[j] 보존)
  · left = 전사 단어 T[j] 컷(대본에 없는 삽입 = 군말/NG)
  · up   = 대본 단어 건너뜀(ASR 누락)
유사도는 조사 차이/발음 흔들림을 흡수(접두 일치·문자 비율). 같은 대본 단어가
전사에 여러 번 나오면 '뒤쪽(마지막 테이크)'을 보존하도록 미세 편향을 준다.
"""

from __future__ import annotations

import re
from difflib import SequenceMatcher

from .asr import Word

_PUNCT = re.compile(r"[^\w가-힣%]")


def _norm(token: str) -> str:
    return _PUNCT.sub("", token.strip())


def _sim(a: str, b: str) -> float:
    """두 어절 유사도 0~1. 조사 차이(접두 일치)와 발음 흔들림을 흡수."""
    if a == b:
        return 1.0
    if not a or not b:
        return 0.0
    if a.startswith(b) or b.startswith(a):
        return min(len(a), len(b)) / max(len(a), len(b))
    return SequenceMatcher(None, a, b).ratio()


def align_cut_spans(
    words: list[Word],
    script_text: str,
    match_th: float = 0.6,
    weak_th: float = 0.4,
    min_match_frac: float = 0.35,
) -> tuple[list[tuple[float, float]], dict]:
    """전사를 대본에 정렬해 '컷할 전사 구간' 목록을 반환.

    반환: (cut_spans, info). info["matched_frac"] 가 min_match_frac 미만이면
    대본/전사 불일치가 커서 신뢰 불가 → 컷 없이 반환(info["unreliable"]=True).
    """
    T = [_norm(w.text) for w in words]
    R = [_norm(x) for x in script_text.split() if _norm(x)]
    n, m = len(T), len(R)
    if n == 0 or m == 0:
        return [], {"matched_frac": 0.0, "unreliable": True}

    NEG = float("-inf")
    CUT, SKIP, EPS = -0.5, -0.8, 1e-3
    dp = [[NEG] * (n + 1) for _ in range(m + 1)]
    bt = [[""] * (n + 1) for _ in range(m + 1)]
    dp[0][0] = 0.0
    for j in range(1, n + 1):
        dp[0][j] = dp[0][j - 1] + CUT
        bt[0][j] = "L"
    for i in range(1, m + 1):
        dp[i][0] = dp[i - 1][0] + SKIP
        bt[i][0] = "U"

    for i in range(1, m + 1):
        for j in range(1, n + 1):
            s = _sim(R[i - 1], T[j - 1])
            if s >= match_th:
                mscore = 2.0
            elif s >= weak_th:
                mscore = 0.3
            else:
                mscore = -1.0
            mscore += EPS * j  # 동점 시 '뒤쪽(마지막 테이크)' 선호
            best, mv = dp[i - 1][j - 1] + mscore, "D"
            if dp[i][j - 1] + CUT > best:
                best, mv = dp[i][j - 1] + CUT, "L"
            if dp[i - 1][j] + SKIP > best:
                best, mv = dp[i - 1][j] + SKIP, "U"
            dp[i][j], bt[i][j] = best, mv

    # 역추적 → 각 전사 단어 keep/cut
    i, j = m, n
    keep = [False] * n
    matched = 0
    while i > 0 or j > 0:
        mv = bt[i][j]
        if mv == "D":
            if _sim(R[i - 1], T[j - 1]) >= weak_th:
                keep[j - 1] = True
                matched += 1
            i -= 1
            j -= 1
        elif mv == "L":
            j -= 1
        else:
            i -= 1

    frac = matched / min(m, n) if min(m, n) else 0.0
    if frac < min_match_frac:
        return [], {"matched_frac": frac, "unreliable": True}

    spans: list[tuple[float, float]] = []
    run: list[float] | None = None
    for idx, w in enumerate(words):
        if not keep[idx]:
            if run is None:
                run = [w.start, w.end]
            else:
                run[1] = w.end
        elif run is not None:
            spans.append((run[0], run[1]))
            run = None
    if run is not None:
        spans.append((run[0], run[1]))

    return spans, {"matched_frac": frac}

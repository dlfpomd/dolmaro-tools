"""CapCut 드래프트를 root_meta_info.json 에 등록 — 목록에 안정적으로 뜨도록.

pycapcut 은 드래프트 폴더만 만들고 CapCut 의 마스터 색인(root_meta_info.json)에는
등록하지 않는다. 그래서 CapCut 이 폴더를 우연히 스캔할 때만 가끔 뜨고, 종종
tm_duration=0(빈 프로젝트)으로 잘못 등록돼 목록에서 사라진다. 여기서 올바른
길이와 함께 직접 등록/갱신한다(쓰기 전 백업 + 원자적 교체로 안전하게).
"""

from __future__ import annotations

import json
import os
import shutil
import time
import uuid
from pathlib import Path

_META_NAMES = ("root_meta_info.json", "root_meta_info")


def _now_us() -> int:
    return int(time.time() * 1_000_000)


def _detect_sep(entry: dict) -> str:
    """기존 색인 항목이 쓰는 경로 구분자(Windows=\\, Mac=/)를 감지한다."""
    sample = "".join(str(entry.get(k, "")) for k in
                     ("draft_fold_path", "draft_root_path", "draft_json_file"))
    if "\\" in sample:
        return "\\"
    if "/" in sample:
        return "/"
    return os.sep


def _to_sep(path: str, sep: str) -> str:
    """경로 구분자를 sep 하나로 통일한다(한 경로에 \\ 와 / 가 섞이지 않도록)."""
    other = "/" if sep == "\\" else "\\"
    return path.replace(other, sep)


def find_meta_file(draft_folder: str | Path) -> Path | None:
    folder = Path(draft_folder)
    for name in _META_NAMES:
        f = folder / name
        if f.exists():
            return f
    return None


def register_draft(
    draft_folder: str | Path,
    draft_name: str,
    duration_seconds: float,
    materials_size: int = 0,
) -> str:
    """root_meta_info 에 드래프트를 등록/갱신한다. 반환: 상태 메시지.

    같은 이름 항목이 있으면 갱신(잘못된 dur=0 교정), 없으면 맨 앞에 삽입.
    """
    meta = find_meta_file(draft_folder)
    if meta is None:
        return "색인 파일 없음 — 등록 생략(CapCut 한 번 실행 후 다시 시도하세요)"
    try:
        data = json.loads(meta.read_text(encoding="utf-8"))
    except Exception as e:
        return f"색인 읽기 실패 — 등록 생략: {e}"

    store = data.get("all_draft_store")
    if not isinstance(store, list) or not store:
        return "색인 형식이 예상과 달라 등록 생략(드래프트 자체는 정상)"

    # CapCut 이 실제 쓰는 구분자를 따른다 — 한 항목 안에서 / 와 \ 가 섞이면
    # CapCut 이 디스크 폴더와 매칭에 실패해 목록에서 사라진다(Windows 백슬래시).
    sep = _detect_sep(store[0])
    root = _to_sep(data.get("root_path") or str(Path(draft_folder)), sep)
    fold = f"{root}{sep}{draft_name}"
    now = _now_us()
    dur_us = max(0, int(round(duration_seconds * 1_000_000)))

    # 기존 항목을 복제해 스키마를 정확히 맞춘 뒤 식별 필드만 덮어쓴다.
    entry = dict(store[0])
    entry.update({
        "draft_cover": f"{fold}{sep}draft_cover.jpg",
        "draft_fold_path": fold,
        "draft_json_file": f"{fold}{sep}draft_content.json",
        "draft_root_path": root,
        "draft_name": draft_name,
        "draft_id": str(uuid.uuid4()).upper(),
        "draft_is_invisible": False,
        "streaming_edit_draft_ready": True,
        "tm_draft_create": now,
        "tm_draft_modified": now,
        "tm_draft_removed": 0,
        "tm_duration": dur_us,
        "draft_timeline_materials_size":
            materials_size or store[0].get("draft_timeline_materials_size", 0) or 1,
    })

    idx = next((i for i, x in enumerate(store)
                if x.get("draft_name") == draft_name), None)
    if idx is not None:
        # 기존 식별자/생성시각은 유지하고 내용만 교정
        entry["draft_id"] = store[idx].get("draft_id") or entry["draft_id"]
        entry["tm_draft_create"] = store[idx].get("tm_draft_create") or now
        store[idx] = entry
        action = "갱신"
    else:
        store.insert(0, entry)
        if isinstance(data.get("draft_ids"), int):
            data["draft_ids"] += 1
        action = "등록"

    # 최초 1회 백업 보존(원본 안전), 원자적 교체로 손상 방지
    backup = meta.with_name(meta.name + ".bak")
    if not backup.exists():
        try:
            shutil.copy2(meta, backup)
        except Exception:
            pass
    tmp = meta.with_name(meta.name + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, separators=(",", ":")),
                   encoding="utf-8")
    os.replace(tmp, meta)
    return f"{action} 완료 (길이 {duration_seconds:.1f}s)"

@echo off
chcp 65001 >nul
title 캡컷 에이전트
cd /d "%~dp0"

where python >nul 2>&1 && set PYTHON=python
if defined PYTHON goto run
where py >nul 2>&1 && set PYTHON=py

:run
if not defined PYTHON goto nopython
%PYTHON% run.py
echo.
echo  ============================================
echo   프로그램이 종료되었습니다.
echo   문제가 있었다면 위 내용을 캡처해서 보내주세요.
echo  ============================================
pause
goto end

:nopython
echo.
echo  ============================================
echo   Python 이 설치되어 있지 않습니다.
echo  ============================================
echo.
echo   1) 잠시 후 열리는 페이지에서 Python 을 설치하세요. (무료)
echo   2) 설치 화면에서 "Add Python to PATH" 를 꼭 체크하세요!
echo   3) 설치가 끝나면 이 파일(start.bat)을 다시 더블클릭하세요.
echo.
start "" https://www.python.org/downloads/
pause

:end

"""원클릭 런처 — 윈도우에서 start.bat 이 이 파일을 실행한다.

처음 실행 시 필요한 구성요소를 자동 설치하고, 웹 UI 를 띄운 뒤 브라우저를 연다.
사용자는 명령어를 칠 필요가 없다. (Python 만 미리 설치돼 있으면 됨.)
"""

from __future__ import annotations

import importlib
import subprocess
import sys
import threading
import time
import webbrowser
from pathlib import Path

HERE = Path(__file__).resolve().parent
DEFAULT_PORT = 8000


def find_free_port(start: int = DEFAULT_PORT, tries: int = 40) -> int:
    """사용 가능한 포트를 찾는다(이전 인스턴스가 8000 을 점유 중일 때 충돌 회피)."""
    import socket
    for p in range(start, start + tries):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.bind(("127.0.0.1", p))
            s.close()
            return p
        except OSError:
            s.close()
            continue
    return start


# 무음 컷 전용 — 가벼운 의존성만(무거운 음성인식 제외).
REQUIRED = ["fastapi", "uvicorn", "multipart", "pycapcut", "imageio_ffmpeg"]
REQ_FILES = ["requirements.txt", "requirements-web.txt"]


def _missing() -> list[str]:
    out = []
    for mod in REQUIRED:
        try:
            importlib.import_module(mod)
        except Exception:
            out.append(mod)
    return out


def ensure_deps() -> None:
    if not _missing():
        return
    print("=" * 50)
    print("  처음 한 번, 필요한 구성요소를 설치합니다.")
    print("  인터넷이 필요하고 몇 분 걸립니다. 기다려 주세요...")
    print("=" * 50)
    cmd = [sys.executable, "-m", "pip", "install", "--upgrade"]
    for r in REQ_FILES:
        cmd += ["-r", str(HERE / r)]
    try:
        subprocess.check_call(cmd)
    except subprocess.CalledProcessError:
        print("\n[오류] 설치에 실패했습니다. 인터넷 연결을 확인하고 다시 실행하세요.")
        input("엔터를 누르면 닫힙니다...")
        sys.exit(1)
    still = _missing()
    if still:
        print(f"\n[오류] 일부 구성요소가 빠졌습니다: {still}")
        input("엔터를 누르면 닫힙니다...")
        sys.exit(1)
    print("\n[완료] 설치 끝!\n")


def main() -> None:
    # 압축을 제대로 풀었는지 확인 (ZIP 안에서 바로 실행하면 파일이 없다)
    if not (HERE / "capcut_agent").is_dir() or not (HERE / "requirements.txt").exists():
        print("[오류] 프로그램 파일을 찾지 못했습니다.")
        print("  ZIP을 먼저 '압축 풀기' 한 뒤, 풀린 폴더 안의 start.bat 을 실행하세요.")
        print("  (ZIP 파일 안에서 바로 더블클릭하면 동작하지 않습니다.)")
        input("\n엔터를 누르면 닫힙니다...")
        return

    ensure_deps()

    port = find_free_port()
    url = f"http://127.0.0.1:{port}"

    def open_when_ready():
        import socket
        for _ in range(120):  # 최대 60초 대기
            try:
                with socket.create_connection(("127.0.0.1", port), timeout=0.5):
                    break
            except OSError:
                time.sleep(0.5)
        webbrowser.open(url)

    threading.Thread(target=open_when_ready, daemon=True).start()

    print("=" * 50)
    print("  캡컷 에이전트 실행 중")
    print(f"  준비되면 브라우저가 자동으로 열립니다 → {url}")
    print("  (안 열리면 브라우저 주소창에 위 주소를 직접 입력하세요.)")
    print("  종료하려면 이 검은 창을 닫으세요.")
    print("=" * 50)

    import uvicorn
    from capcut_agent.server import app  # 의존성 설치 후 import

    uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
    except Exception:
        import traceback
        print("\n" + "=" * 50)
        print("  [오류 발생] 아래 내용을 캡처해서 보내주시면 고쳐드립니다:")
        print("=" * 50)
        traceback.print_exc()
        input("\n엔터를 누르면 닫힙니다...")


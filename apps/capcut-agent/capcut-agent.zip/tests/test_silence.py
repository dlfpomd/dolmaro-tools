"""compute_keeps 순수 로직 테스트 (ffmpeg 불필요)."""

from capcut_agent.silence import Segment, compute_keeps


def _tuples(segs):
    return [(round(s.start, 3), round(s.end, 3)) for s in segs]


def test_complement_basic():
    # 10초 영상, 무음 [2,4],[6,7]. pad=0 → 보존 [0,2],[4,6],[7,10].
    keeps = compute_keeps([Segment(2, 4), Segment(6, 7)], 10.0, pad=0.0, min_keep=0.0)
    assert _tuples(keeps) == [(0, 2), (4, 6), (7, 10)]


def test_padding_shrinks_silence():
    # pad=0.05 → 무음이 안쪽으로 줄어 보존 구간이 양쪽으로 늘어난다.
    keeps = compute_keeps([Segment(2, 4)], 6.0, pad=0.05, min_keep=0.0)
    assert _tuples(keeps) == [(0, 2.05), (3.95, 6)]


def test_leading_silence():
    # 처음부터 무음이면 첫 보존 구간은 무음 끝부터 시작.
    keeps = compute_keeps([Segment(0, 1.5)], 5.0, pad=0.0, min_keep=0.0)
    assert _tuples(keeps) == [(1.5, 5)]


def test_trailing_silence():
    keeps = compute_keeps([Segment(4, 5)], 5.0, pad=0.0, min_keep=0.0)
    assert _tuples(keeps) == [(0, 4)]


def test_min_keep_drops_tiny():
    # [0,0.05] 조각은 min_keep=0.1 로 버려진다.
    keeps = compute_keeps([Segment(0.05, 3)], 5.0, pad=0.0, min_keep=0.1)
    assert _tuples(keeps) == [(3, 5)]


def test_no_silence_returns_whole():
    keeps = compute_keeps([], 8.0, pad=0.05, min_keep=0.1)
    assert _tuples(keeps) == [(0, 8)]


def test_overlapping_silences_merge():
    keeps = compute_keeps([Segment(2, 4), Segment(3, 5)], 8.0, pad=0.0, min_keep=0.0)
    assert _tuples(keeps) == [(0, 2), (5, 8)]

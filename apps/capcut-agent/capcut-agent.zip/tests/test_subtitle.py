"""자막 청커 불변식 + SRT 생성 테스트 (네트워크/ASR 불필요)."""

from capcut_agent.asr import Word
from capcut_agent.silence import Segment
from capcut_agent.subtitle import (
    BOUND_NOUNS,
    Cue,
    chunk_words,
    map_time_to_cut,
    remap_cues_to_cut,
    remap_words_to_cut,
    to_srt,
    _ts,
)


def _stream(text, gap=0.0, wdur=0.3):
    """공백 분리 어절을 균등 타임스탬프 단어 스트림으로."""
    words = []
    t = 0.0
    for tok in text.split():
        words.append(Word(t, t + wdur, tok))
        t += wdur + gap
    return words


def test_never_starts_line_with_bound_noun():
    # '진행될 수 있습니다' → '수' 앞에서 끊으면 안 됨
    words = _stream("여러 면에서 다르게 진행될 수 있습니다.", gap=0.05)
    cues = chunk_words(words, max_chars=6, hard_max=10)  # 일부러 빡빡하게
    for c in cues:
        assert c.text.split()[0] not in BOUND_NOUNS, c.text


def test_sentence_punctuation_forces_break():
    words = _stream("끝입니다. 새 문장 시작", gap=0.0)
    cues = chunk_words(words, max_chars=100, hard_max=100, pause_break=99)
    assert cues[0].text.endswith("끝입니다.")
    assert len(cues) == 2


def test_pause_triggers_break():
    # 명시적 타임라인: 두 어절 뒤 0.5s 쉼, 다시 두 어절
    words = [
        Word(0.0, 0.3, "앞쪽"),
        Word(0.3, 0.6, "구절입니다"),   # 끝 0.6
        Word(1.1, 1.4, "뒤쪽"),         # 쉼 0.5s
        Word(1.4, 1.7, "구절입니다"),
    ]
    cues = chunk_words(words, max_chars=100, hard_max=100, pause_break=0.3)
    assert len(cues) == 2, [c.text for c in cues]


def test_hard_max_respected_when_possible():
    words = _stream("가나다라마바사아자차카타파하 가나다라마바사아자차카타파하", gap=0.0)
    cues = chunk_words(words, max_chars=10, hard_max=16)
    for c in cues:
        assert len(c.text.replace(" ", "")) <= 16 + 2  # 약간의 여유


def test_su_issumnida_stays_together():
    words = _stream("나타날 수 있습니다.", gap=0.02)
    cues = chunk_words(words, max_chars=4, hard_max=8)
    joined = " ".join(c.text for c in cues)
    assert "수 있습니다." in joined.replace("  ", " ")
    # '수' 가 어느 줄에서도 첫 어절이면 안 됨
    for c in cues:
        assert c.text.split()[0] != "수"


def test_srt_timestamp_format():
    assert _ts(0) == "00:00:00,000"
    assert _ts(1.833) == "00:00:01,833"
    assert _ts(75.5) == "00:01:15,500"


def test_map_time_to_cut():
    keeps = [Segment(0, 2), Segment(4, 6), Segment(7, 10)]
    assert map_time_to_cut(1.0, keeps) == 1.0       # 보존 구간, 이동 없음
    assert map_time_to_cut(3.0, keeps) is None       # 제거 구간
    assert map_time_to_cut(5.0, keeps) == 3.0        # 2s 제거분 앞당김
    assert map_time_to_cut(8.0, keeps) == 5.0        # 3s 제거분 앞당김


def test_remap_drops_cue_in_removed_region():
    keeps = [Segment(0, 2), Segment(4, 6), Segment(7, 10)]
    cues = [
        Cue(1, 1.0, 1.5, "A"),   # 보존 → 유지
        Cue(2, 5.0, 5.5, "B"),   # → 3.0-3.5
        Cue(3, 6.2, 6.8, "C"),   # 제거 구간 → 버림
        Cue(4, 8.0, 9.0, "D"),   # → 5.0-6.0
    ]
    out = remap_cues_to_cut(cues, keeps)
    assert [c.text for c in out] == ["A", "B", "D"]
    assert (out[1].start, out[1].end) == (3.0, 3.5)
    assert (out[2].start, out[2].end) == (5.0, 6.0)
    # 재인덱싱 확인
    assert [c.index for c in out] == [1, 2, 3]


def test_remap_words_drops_cut_words():
    # 보존 [0,2],[4,6] (즉 [2,4] 컷). [2,4] 안의 단어는 자막에서 제외돼야.
    keeps = [Segment(0, 2), Segment(4, 6)]
    words = [
        Word(0.5, 0.9, "유지A"),     # → 0.5
        Word(2.5, 2.9, "잔말"),       # 컷 구간 → 제외
        Word(4.5, 4.9, "유지B"),     # → 2.5 (2s 앞당김)
    ]
    out = remap_words_to_cut(words, keeps)
    assert [w.text for w in out] == ["유지A", "유지B"]
    assert out[0].start == 0.5
    assert out[1].start == 2.5


def test_to_srt_structure():
    words = _stream("첫 줄입니다. 둘째 줄입니다.", gap=0.0)
    cues = chunk_words(words, max_chars=100, hard_max=100, pause_break=99)
    srt = to_srt(cues)
    assert "1\n00:00:00,000 -->" in srt
    assert "-->" in srt

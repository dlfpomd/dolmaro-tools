"""잔말/NG 감지 + 구간 빼기 테스트."""

from capcut_agent.asr import Word
from capcut_agent.silence import Segment
from capcut_agent.filler import (
    detect_filler_spans,
    detect_ng_spans,
    merge_spans,
    subtract_spans,
)


def _stream(text, t0=0.0, wdur=0.3, gap=0.05):
    ws, t = [], t0
    for tok in text.split():
        ws.append(Word(t, t + wdur, tok))
        t += wdur + gap
    return ws


def test_filler_detects_standalone_only():
    # 잔말 사이에 내용어를 둬 각각 분리되게(인접 병합 회피).
    ws = _stream("어 오늘은 음 쇼그렌 그 이야기를 그것은 합니다")
    spans = detect_filler_spans(ws)
    # '어','음','그' 3개. '그것은' 은 부분매치 아님 → 제외.
    assert len(spans) == 3


def test_filler_custom_set():
    ws = _stream("자 시작합니다 자 갑니다")
    spans = detect_filler_spans(ws, fillers={"자"})
    assert len(spans) == 2


def test_filler_merges_adjacent():
    ws = [Word(0.0, 0.3, "어"), Word(0.35, 0.6, "음"), Word(2.0, 2.3, "말")]
    spans = detect_filler_spans(ws)
    assert spans == [(0.0, 0.6)]  # 인접 어+음 병합


def test_ng_cuts_first_take():
    ws = _stream("이 약은 효과적입니다 다시 이 약은 효과적입니다 끝")
    ng = detect_ng_spans(ws, min_run=3)
    assert len(ng) == 1
    cs, ce = ng[0]
    # 첫 테이크 시작(0.0)부터 둘째 테이크 시작까지
    assert cs == ws[0].start
    assert ce == ws[4].start  # 둘째 '이'


def test_ng_no_false_positive_on_unique_speech():
    ws = _stream("오늘은 쇼그렌증후군에 대해 알아보겠습니다 시작할게요")
    assert detect_ng_spans(ws, min_run=3) == []


def test_ng_fuzzy_catches_asr_variation():
    # 음성인식이 같은 말을 조금씩 다르게 받아써도(조사/철자) 첫 테이크를 잡는다.
    ws = _stream("그렇지만 구강작열감 증후군은 그렇지만은 구강작열 증후군이 이런 질환")
    ng = detect_ng_spans(ws, min_run=3)
    assert len(ng) == 1
    cs, ce = ng[0]
    assert cs == ws[0].start          # 첫 테이크 시작
    assert ce == ws[3].start          # 둘째 테이크 시작


def test_ng_no_false_positive_short_repeat():
    # "네 네" 같은 짧은 반복은 컷하지 않는다(2글자+ 토큰 부족).
    ws = _stream("네 네 알겠습니다 감사합니다")
    assert detect_ng_spans(ws, min_run=3) == []


def test_merge_spans():
    assert merge_spans([(0, 2), (1, 3), (5, 6)]) == [(0, 3), (5, 6)]
    assert merge_spans([]) == []


def test_subtract_splits_keep():
    out = subtract_spans([Segment(0, 10)], [(2, 3)], min_keep=0.1)
    assert [(s.start, s.end) for s in out] == [(0, 2), (3, 10)]


def test_subtract_drops_tiny_pieces():
    # [0,10] 에서 [0.05,9.95] 컷 → 양끝 0.05 조각은 min_keep 로 버림
    out = subtract_spans([Segment(0, 10)], [(0.05, 9.95)], min_keep=0.1)
    assert out == []


def test_subtract_span_outside_keep_noop():
    out = subtract_spans([Segment(0, 2)], [(5, 6)], min_keep=0.1)
    assert [(s.start, s.end) for s in out] == [(0, 2)]

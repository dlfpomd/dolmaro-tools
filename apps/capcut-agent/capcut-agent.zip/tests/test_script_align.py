"""원본 대본 정렬 기반 NG 교정 테스트 (사용자 실제 사례 포함)."""

from capcut_agent.asr import Word
from capcut_agent.script_align import align_cut_spans, _sim


def _stream(toks, d=0.3, g=0.05):
    ws, t = [], 0.0
    for tok in toks:
        ws.append(Word(t, t + d, tok))
        t += d + g
    return ws


def _cut_indices(toks, script):
    ws = _stream(toks)
    spans, info = align_cut_spans(ws, script)
    idx = [i for i, w in enumerate(ws) if any(s <= w.start < e for s, e in spans)]
    return idx, info


def test_incomplete_repeat_cuts_false_start():
    # 사용자 사례1: 앞 "두가지 개념이 포함"(false start)을 잘라야.
    toks = ["두가지", "개념이", "포함", "두가지", "개념이", "포함되어", "있습니다"]
    idx, info = _cut_indices(toks, "두가지 개념이 포함되어 있습니다")
    assert idx == [0, 1, 2]
    assert info["matched_frac"] == 1.0


def test_phonetic_restart_stutter():
    # 사용자 사례2: "인, 인후 이물" 더듬음 제거, "인두이물감…" 보존.
    toks = ["인", "인후", "이물", "인두이물감등이", "여기", "포함됩니다"]
    idx, _ = _cut_indices(toks, "인두이물감이 여기에 포함됩니다")
    assert idx == [0, 1, 2]


def test_fillers_cut_by_script():
    # 대본만 줘도 군말("어/음")은 삽입이라 잘린다.
    toks = ["어", "오늘은", "음", "쇼그렌증후군을", "알아봅니다"]
    idx, _ = _cut_indices(toks, "오늘은 쇼그렌증후군을 알아봅니다")
    assert idx == [0, 2]


def test_clean_take_no_cuts():
    toks = ["오늘은", "쇼그렌증후군을", "알아봅니다"]
    idx, _ = _cut_indices(toks, "오늘은 쇼그렌증후군을 알아봅니다")
    assert idx == []


def test_unreliable_script_no_cuts():
    # 대본이 영상과 전혀 안 맞으면(매칭 낮음) 컷하지 않는다(안전).
    toks = ["가나다", "라마바", "사아자"]
    spans, info = align_cut_spans(_stream(toks), "전혀 다른 대본 내용입니다 정말로")
    assert info.get("unreliable") is True
    assert spans == []


def test_sim_prefix_handles_josa():
    # 조사 차이는 높은 유사도(접두 일치).
    assert _sim("여기에", "여기") > 0.6
    assert _sim("인두이물감이", "인두이물감등이") > 0.6
    assert _sim("사과", "바나나") < 0.4

"""root_meta_info 등록 테스트."""

import json

from capcut_agent.capcut_register import register_draft


_WIN_ROOT = r"C:\Users\u\AppData\Local\CapCut\User Data\Projects\com.lveditor.draft"


def _minimal_meta(tmp_path, root=_WIN_ROOT, sep="\\"):
    """기존 항목 1개를 가진 최소 색인 파일(CapCut 실제 경로 형식)."""
    entry = {
        "draft_name": "기존드래프트",
        "draft_id": "OLD-ID",
        "draft_cover": f"{root}{sep}기존드래프트{sep}draft_cover.jpg",
        "draft_fold_path": f"{root}{sep}기존드래프트",
        "draft_json_file": f"{root}{sep}기존드래프트{sep}draft_content.json",
        "draft_root_path": root, "draft_new_version": "164.0.0",
        "draft_timeline_materials_size": 100, "draft_is_invisible": False,
        "streaming_edit_draft_ready": True,
        "tm_draft_create": 111, "tm_draft_modified": 111,
        "tm_draft_removed": 0, "tm_duration": 5000000,
    }
    data = {"all_draft_store": [entry],
            "draft_ids": 0,
            "root_path": root}
    meta = tmp_path / "root_meta_info.json"
    meta.write_text(json.dumps(data), encoding="utf-8")
    return meta


def test_register_new_draft(tmp_path):
    meta = _minimal_meta(tmp_path)
    msg = register_draft(tmp_path, "새드래프트_agent", 42.0, materials_size=999)
    assert "등록" in msg
    data = json.loads(meta.read_text(encoding="utf-8"))
    assert len(data["all_draft_store"]) == 2
    assert data["draft_ids"] == 1
    new = data["all_draft_store"][0]            # 맨 앞에 삽입
    assert new["draft_name"] == "새드래프트_agent"
    assert new["tm_duration"] == 42_000_000     # 길이 정확
    # Windows 색인 → 모든 경로가 백슬래시로 통일(섞임 없음)
    assert new["draft_fold_path"].endswith("\\새드래프트_agent")
    assert new["draft_json_file"].endswith("\\새드래프트_agent\\draft_content.json")
    assert new["draft_cover"].endswith("\\새드래프트_agent\\draft_cover.jpg")
    for key in ("draft_fold_path", "draft_json_file", "draft_cover", "draft_root_path"):
        assert "/" not in new[key], f"{key} 에 슬래시 섞임: {new[key]}"
    # 백업 생성
    assert (tmp_path / "root_meta_info.json.bak").exists()


def test_register_mac_uses_forward_slash(tmp_path):
    """Mac 색인(슬래시) → 새 항목도 슬래시로 통일(백슬래시 섞임 없음)."""
    mac_root = "/Users/u/Movies/CapCut/User Data/Projects/com.lveditor.draft"
    _minimal_meta(tmp_path, root=mac_root, sep="/")
    register_draft(tmp_path, "맥드래프트_agent", 12.0)
    data = json.loads((tmp_path / "root_meta_info.json").read_text(encoding="utf-8"))
    new = data["all_draft_store"][0]
    assert new["draft_fold_path"].endswith("/맥드래프트_agent")
    assert new["draft_json_file"].endswith("/맥드래프트_agent/draft_content.json")
    for key in ("draft_fold_path", "draft_json_file", "draft_cover", "draft_root_path"):
        assert "\\" not in new[key], f"{key} 에 백슬래시 섞임: {new[key]}"


def test_register_updates_existing_zero_duration(tmp_path):
    meta = _minimal_meta(tmp_path)
    # dur=0 으로 깨진 항목을 추가
    data = json.loads(meta.read_text(encoding="utf-8"))
    data["all_draft_store"].append({
        **data["all_draft_store"][0], "draft_name": "깨진_agent",
        "draft_id": "KEEP-ID", "tm_duration": 0, "tm_draft_create": 222,
    })
    meta.write_text(json.dumps(data), encoding="utf-8")

    msg = register_draft(tmp_path, "깨진_agent", 96.8)
    assert "갱신" in msg
    data = json.loads(meta.read_text(encoding="utf-8"))
    fixed = [x for x in data["all_draft_store"] if x["draft_name"] == "깨진_agent"]
    assert len(fixed) == 1                       # 중복 추가 안 함
    assert fixed[0]["tm_duration"] == 96_800_000  # 0 → 교정
    assert fixed[0]["draft_id"] == "KEEP-ID"     # 기존 식별자 유지
    assert fixed[0]["tm_draft_create"] == 222


def test_register_no_meta_file_is_safe(tmp_path):
    msg = register_draft(tmp_path, "x_agent", 10.0)
    assert "생략" in msg                          # 파일 없으면 조용히 생략

"""드래프트 생성 통합 테스트 (ffmpeg + pycapcut 있을 때만).

ffprobe/소재 길이 µs 불일치로 인한 '범위 초과' 회귀를 방어한다.
"""

import json
import shutil
import subprocess

import pytest

pytest.importorskip("pycapcut")

if shutil.which("ffmpeg") is None or shutil.which("ffprobe") is None:
    pytest.skip("ffmpeg/ffprobe 없음", allow_module_level=True)

from capcut_agent.draft import build_jumpcut_draft
from capcut_agent.silence import analyze


def _make_sample(path, seconds=4):
    # 1s 소리 / 1s 무음 반복.
    subprocess.run(
        ["ffmpeg", "-y", "-f", "lavfi", "-i", f"color=c=red:s=320x240:r=30:d={seconds}",
         "-f", "lavfi", "-i", f"sine=frequency=440:d={seconds}",
         "-af", "volume=enable='lt(mod(t,2),1)':volume=1,volume=enable='gte(mod(t,2),1)':volume=0",
         "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-shortest", str(path)],
        check=True, capture_output=True,
    )


def test_jumpcut_draft_contiguous_and_in_bounds(tmp_path):
    video = tmp_path / "s.mp4"
    _make_sample(video)
    keeps, _silences, duration = analyze(str(video), min_silence=0.4, pad=0.05)
    assert keeps, "보존 구간이 있어야 함"

    folder = tmp_path / "drafts"
    draft_path, final_len = build_jumpcut_draft(
        str(video), keeps, "t", folder, fps=30
    )

    content = json.loads((folder / "t" / "draft_content.json").read_text())
    mat_dur = max(m["duration"] for m in content["materials"]["videos"])
    track = next(t for t in content["tracks"] if t["type"] == "video")
    segs = track["segments"]
    assert segs

    cursor = 0
    for s in segs:
        tr, sr = s["target_timerange"], s["source_timerange"]
        assert tr["start"] == cursor, "타임라인이 연속(빈틈 없음)이어야 함"
        cursor += tr["duration"]
        # 소스가 소재 길이를 넘지 않아야 함 (클램프 회귀 방지)
        assert sr["start"] + sr["duration"] <= mat_dur
    assert abs(cursor / 1_000_000 - final_len) < 1e-6

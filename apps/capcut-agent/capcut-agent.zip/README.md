# 캡컷 에이전트 (CapCut Agent)

한국어 토킹 영상 자동 편집기. 입력 `mp4/mov` → 출력 **CapCut 드래프트**
(무음·NG 컷 + 자막). 검증은 항상 **CapCut에서 직접 재생**으로 한다.
빌드 성공 ≠ 검증.

## 윈도우 빠른 시작 (명령어 없이) ⭐

1. 초록색 **Code → Download ZIP** 으로 내려받아 압축을 푼다.
2. 폴더 안 **`start.bat`** 을 더블클릭한다.
   - 파이썬이 없으면 설치 페이지가 열린다 → 설치 시 **"Add Python to PATH" 체크**.
   - 처음 한 번 필요한 구성요소가 자동 설치된다(몇 분).
3. 브라우저가 자동으로 열린다 → 영상을 끌어다 놓고 **처리 시작**.

자세한 그림 설명은 **`윈도우_사용법.txt`** 참고. `ffmpeg` 는 pip 로 자동 번들되어
**따로 설치할 필요 없다**.

## 빌드 적층 (각 단계 CapCut 재생 검증 후 다음)

| 단계 | 내용 | 상태 |
|------|------|------|
| **1단** | `silence_detect` + `build_draft` → 점프컷 드래프트 (UI 없음) | ✅ 구현 |
| **2단** | FastAPI + 정적 HTML (drag/drop + SSE stepper) | ✅ 구현 |
| **3단** | whisper Transcript + 구 단위 자막 + 컷 타임라인 재매핑 | ✅ 구현 |
| **4단** | 잔말(filler) + NG(반복 테이크) 통합 컷 + 대본 노출 | ✅ 구현 |
| 5단 | 영상 프리뷰 + 보존 구간 사용자 마킹 | 예정 |

## 실행 트랙 (Step 0 OS 감지)

| 트랙 | 환경 | ASR 백엔드 |
|------|------|-----------|
| A | Mac (Apple Silicon) | mlx-whisper |
| C | Windows (AMD64) | faster-whisper (+MP4 export) |
| **fallback** | Mac Intel(x86_64) / 그 외 | faster-whisper |

> 이 저장소 사용자 환경은 **Windows → 트랙 C** (faster-whisper, MP4 export 가능).
> 드래프트 폴더: `%LOCALAPPDATA%\CapCut\User Data\Projects\com.lveditor.draft`

## 사전 설치 (Mac Intel 기준)

```bash
brew install ffmpeg            # 무음 감지/길이 측정에 필수
python3 -m pip install -r requirements.txt
```

CapCut 드래프트 폴더가 존재해야 한다(없으면 CapCut 설치 + 1회 실행).
Mac 기본 경로:
`~/Movies/CapCut/User Data/Projects/com.lveditor.draft`

## 1단 사용법 — 무음 점프컷 드래프트

```bash
python3 -m capcut_agent.cli 내영상.mp4
# 옵션
python3 -m capcut_agent.cli 내영상.mp4 \
  --name 내쇼츠 --min-silence 0.4 --noise -30 --pad 0.05
```

출력 예:
```
● 트랙 fallback · Darwin (x86_64) · ASR=faster-whisper
● 분석 중: 내영상.mp4
  원본  62.30s · 무음 18개 · 보존 19컷  47.10s · 제거 15.20s (24.4%)
✓ 드래프트 저장: .../com.lveditor.draft/내쇼츠
  타임라인 길이 47.10s · CapCut 에서 열어 직접 재생 검증하세요.
```

생성 후 **CapCut을 실행 → 드래프트 목록에서 열기 → 재생**으로 점프컷이
자연스러운지 직접 확인한다.

### 파라미터

| 옵션 | 기본 | 의미 |
|------|------|------|
| `--noise` | -30 | 무음 판정 노이즈 게이트(dB). 낮을수록 더 조용해야 무음 판정 |
| `--min-silence` | 0.5 | 컷 대상 최소 무음 길이(초). 0.4s대 자연 쉼 보존 |
| `--pad` | 0.07 | 컷 경계 여유(초). 말 앞뒤를 바짝 자르지 않게 |
| `--min-keep` | 0.10 | 이보다 짧은 보존 조각은 버림 |

## 2단 사용법 — 로컬 웹 UI

```bash
pip install -r requirements-web.txt
python3 -m capcut_agent.server      # → http://127.0.0.1:8000
```

브라우저에서 영상을 끌어다 놓고 옵션(자막/무음컷/모델/임계값) 선택 후 **처리 시작**.
SSE stepper(무음 → 자막 → 잔말·NG → 드래프트)로 진행이 실시간 표시되고,
완료 시 3컬럼 통계(원본·제거·결과)와 추출 대본이 카드로 나온다. 드래프트는
OS별 CapCut 폴더에 저장된다.

> 런타임: ASR 은 `asyncio.Lock` 으로 직렬화, 단계당 최소 0.5s 지연(애니메이션
> 가시화). ASR 실패해도(모델 미존재 등) 점프컷 드래프트는 계속 생성된다.

## 3단 사용법 — 자막 (ASR + 구 단위 청킹)

먼저 ASR 의존성 설치 (첫 실행 시 whisper 모델 자동 다운로드, **인터넷 필요**):

```bash
pip install -r requirements-asr.txt
```

```bash
# 무음 컷 + 자막 (자막 시각은 컷 타임라인으로 자동 재매핑)
python3 -m capcut_agent.cli 내영상.mp4 --subtitles

# 컷 없이 자막만 (전체 영상 유지)
python3 -m capcut_agent.cli 내영상.mp4 --no-cut --subtitles

# 모델 크기: 품질 large-v3(기본) / 속도 medium
python3 -m capcut_agent.cli 내영상.mp4 --subtitles --sub-model medium
```

생성물: 드래프트에 **자막 텍스트 트랙** + 드래프트 폴더에 `subtitles.srt`.

## 4단 사용법 — 잔말 + NG 컷

```bash
# 무음 + 잔말 + NG + 자막 한 번에 (모두 ASR 기반)
python3 -m capcut_agent.cli 내영상.mp4 --subtitles --filler --ng
```

웹 UI 에서는 **잔말 컷 / NG 컷** 체크박스로 켠다.

- **잔말(filler)**: 단독으로 나온 간투사를 투명 제거. 기본 세트
  `어·음·그·이제·인제·뭐·막·에` (단독 토큰만, 부분 문자열 매치 안 함 →
  "그것은"·"이제까지" 등은 안 잘림). 오컷 위험 큰 "좀/약간"은 기본 제외.
- **NG(반복 테이크)**: 같은 토큰 시퀀스(≥3어절)가 곧이어 반복되면 **앞 테이크를
  잘라 마지막 테이크만** 남김. 대본 위 시퀀스 매칭 기반.
- 컷은 무음 보존 구간에서 빼낸다(`subtract_spans`). **자막은 잘린 단어를 먼저
  제거+재매핑한 뒤 청킹**하므로 자막 내용·싱크가 컷 영상과 정확히 일치한다.

### ⭐ 원본 대본(script) 기반 정밀 NG 교정 — 권장

웹 UI 의 **"원본 대본"** 칸(또는 CLI `--script 대본.txt`)에 의도한 대본을 넣으면,
ASR 전사를 대본에 **강제 정렬**해 대본과 안 맞는 부분(더듬음·false start·재촬영
앞 테이크·군말)을 정확히 잘라낸다. 완전 일치 반복만 잡는 자동 감지보다 훨씬
정확하다 — 예:

- `"두가지 개념이 포함 / 두가지 개념이 포함되어 있습니다"` → 앞 false start 컷
- `"인, 인후 이물 / 인두이물감등이…"` → 발음 재시작 더듬음 컷

정렬 유사도는 조사 차이·발음 흔들림을 흡수한다. 대본이 영상과 너무 안 맞으면
(매칭 < 50%) NG 컷을 생략해 오컷을 막는다. 결과 카드에 **대본일치 %** 가 뜬다.

### 자막 청킹 규칙 (사용자 샘플 SRT 실측 기반)

- **구(phrase) 단위** 자막 — 단어 단위 X (원본 프롬프트 핵심 원칙).
- 끊김 신호: 단어 간 **쉼(pause ≥ 0.12s)** · 문장 종결 · 길이 캡.
- **의존명사(수/것/때/등…)로 줄을 시작하지 않음** — "수 있습니다" 류는 한 줄.
- 한 줄 글자수(공백제외): 소프트 18 / 하드 28 (실측 평균 15 / 최대 23).

## 알려진 함정 / 주의

- **시간 단위는 마이크로초.** `pycapcut.tim(float)` 은 초가 아니라 µs로
  해석되므로 코드는 `int(round(sec * SEC))` 로 직접 변환한다.
- pycapcut 0.0.3 은 `draft_content.json` 을 생성한다(일부 문서가 말하는
  `draft_info.json` 아님). **CapCut 버전에 따라 호환성 확인 필요** —
  반드시 실제로 열어 검증할 것.
- ASR 은 numba 비스레드세이프 → 모듈 락으로 전사 직렬화(동시 호출 시 segfault).
  2단 FastAPI 에서는 `asyncio.Lock` 으로 감싼다.
- whisper 모델 다운로드는 huggingface 접근 필요. 오프라인/제한망에서는 실패하니
  로컬에서 1회 인터넷 연결로 받아둔다.
- 자막 시각은 **원본 타임라인 기준** → 무음 컷 후에는 컷 타임라인으로 재매핑해야
  싱크가 맞는다(`remap_cues_to_cut`, `--subtitles` 사용 시 자동).

## 개발

```bash
python3 -m pytest tests/ -q
```
